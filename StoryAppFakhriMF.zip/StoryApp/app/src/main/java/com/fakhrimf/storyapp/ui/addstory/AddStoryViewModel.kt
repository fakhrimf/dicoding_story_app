package com.fakhrimf.storyapp.ui.addstory

import androidx.lifecycle.ViewModel

class AddStoryViewModel : ViewModel() {

}