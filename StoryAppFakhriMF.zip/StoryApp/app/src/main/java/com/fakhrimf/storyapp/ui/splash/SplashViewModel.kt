package com.fakhrimf.storyapp.ui.splash

import androidx.lifecycle.ViewModel

class SplashViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}