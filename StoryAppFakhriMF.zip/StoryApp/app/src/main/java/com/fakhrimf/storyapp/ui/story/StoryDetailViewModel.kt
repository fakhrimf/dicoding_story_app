package com.fakhrimf.storyapp.ui.story

import androidx.lifecycle.ViewModel

class StoryDetailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}